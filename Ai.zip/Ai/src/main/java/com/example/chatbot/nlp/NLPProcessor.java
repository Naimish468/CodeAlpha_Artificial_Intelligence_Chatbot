package com.example.chatbot.nlp;

import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;

@Component
public class NLPProcessor {

    private SentenceDetectorME sentenceDetector;
    private TokenizerME tokenizer;
    private POSTaggerME posTagger;

    public NLPProcessor() {
        // Initialize with fallback if models are not available
        try {
            initializeModels();
        } catch (IOException e) {
            System.out.println("Warning: NLP models not found. Using fallback processing.");
            // Initialize with null - methods will handle gracefully
        }
    }

    private void initializeModels() throws IOException {
        // Load sentence detection model
        try (InputStream modelIn = new ClassPathResource("models/en-sent.bin").getInputStream()) {
            SentenceModel sentenceModel = new SentenceModel(modelIn);
            sentenceDetector = new SentenceDetectorME(sentenceModel);
        } catch (IOException e) {
            System.out.println("Sentence detection model not found: " + e.getMessage());
            throw e;
        }

        // Load tokenizer model
        try (InputStream modelIn = new ClassPathResource("models/en-token.bin").getInputStream()) {
            TokenizerModel tokenizerModel = new TokenizerModel(modelIn);
            tokenizer = new TokenizerME(tokenizerModel);
        } catch (IOException e) {
            System.out.println("Tokenizer model not found: " + e.getMessage());
            throw e;
        }

        // Load POS tagger model
        try (InputStream modelIn = new ClassPathResource("models/en-pos-maxent.bin").getInputStream()) {
            POSModel posModel = new POSModel(modelIn);
            posTagger = new POSTaggerME(posModel);
        } catch (IOException e) {
            System.out.println("POS tagger model not found: " + e.getMessage());
            throw e;
        }
    }

    public String[] detectSentences(String text) {
        if (sentenceDetector == null) {
            return new String[]{text}; // Fallback: treat whole text as one sentence
        }
        return sentenceDetector.sentDetect(text);
    }

    public String[] tokenize(String text) {
        if (tokenizer == null) {
            return text.split("\\s+"); // Fallback: simple whitespace tokenization
        }
        return tokenizer.tokenize(text);
    }

    public String[] posTag(String[] tokens) {
        if (posTagger == null) {
            // Fallback: assign default POS tags
            String[] tags = new String[tokens.length];
            for (int i = 0; i < tokens.length; i++) {
                tags[i] = "NN"; // Default to noun
            }
            return tags;
        }
        return posTagger.tag(tokens);
    }

    public String extractIntent(String userInput) {
        String[] tokens = tokenize(userInput.toLowerCase());
        String[] tags = posTag(tokens);

        // Simple intent extraction based on keywords and POS tags
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].equals("hello") || tokens[i].equals("hi")) {
                return "greeting";
            } else if (tokens[i].equals("bye") || tokens[i].equals("goodbye")) {
                return "farewell";
            } else if (tokens[i].equals("thank")) {
                return "gratitude";
            } else if (tokens[i].equals("help")) {
                return "help";
            }
        }

        return "unknown";
    }

    public String[] extractEntities(String userInput) {
        // Simple entity extraction - in a real implementation, you'd use NER models
        String[] tokens = tokenize(userInput);
        // For now, return all nouns (NN, NNS, NNP, NNPS)
        String[] tags = posTag(tokens);
        return java.util.Arrays.stream(tokens)
                .filter(token -> {
                    int index = java.util.Arrays.asList(tokens).indexOf(token);
                    return tags[index].startsWith("NN");
                })
                .toArray(String[]::new);
    }
}