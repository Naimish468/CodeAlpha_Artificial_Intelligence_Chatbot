package com.example.chatbot.service;

import com.example.chatbot.ml.MachineLearningService;
import com.example.chatbot.nlp.NLPProcessor;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

@Service
public class ChatbotService {

    private final Map<String, String> faqResponses;
    private final NLPProcessor nlpProcessor;
    private final MachineLearningService mlService;

    public ChatbotService(NLPProcessor nlpProcessor, MachineLearningService mlService) {
        this.nlpProcessor = nlpProcessor;
        this.mlService = mlService;
        faqResponses = new HashMap<>();
        initializeFAQResponses();
    }

    // Fallback constructor for when dependencies are not available
    public ChatbotService() {
        this.nlpProcessor = null;
        this.mlService = null;
        faqResponses = new HashMap<>();
        initializeFAQResponses();
    }

    private void initializeFAQResponses() {
        faqResponses.put("greeting", "Hello! How can I help you today?");
        faqResponses.put("farewell", "Goodbye! Have a great day!");
        faqResponses.put("gratitude", "You're welcome! Is there anything else I can help with?");
        faqResponses.put("help", "I can answer frequently asked questions. Try asking me about common topics!");
        faqResponses.put("unknown", "I'm sorry, I don't understand that question. Can you please rephrase it or ask about something else?");
    }

    public String getResponse(String userInput) {
        String intent = "unknown";

        // Use machine learning for intent prediction if available
        if (mlService != null) {
            intent = mlService.predictIntent(userInput);
        }

        // Fallback to rule-based NLP if ML is not available or confidence is low
        if (intent.equals("unknown") && nlpProcessor != null) {
            intent = nlpProcessor.extractIntent(userInput);
        }

        // Simple keyword-based fallback if NLP is not available
        if (intent.equals("unknown")) {
            intent = extractIntentFallback(userInput);
        }

        // Get response based on intent
        String response = faqResponses.getOrDefault(intent, faqResponses.get("unknown"));

        // Extract entities for more personalized responses if NLP is available
        if (nlpProcessor != null) {
            String[] entities = nlpProcessor.extractEntities(userInput);
            if (entities.length > 0 && intent.equals("unknown")) {
                response += " I noticed you mentioned: " + String.join(", ", entities);
            }
        }

        return response;
    }

    private String extractIntentFallback(String userInput) {
        String lowerInput = userInput.toLowerCase();
        if (lowerInput.contains("hello") || lowerInput.contains("hi")) {
            return "greeting";
        } else if (lowerInput.contains("bye") || lowerInput.contains("goodbye")) {
            return "farewell";
        } else if (lowerInput.contains("thank")) {
            return "gratitude";
        } else if (lowerInput.contains("help")) {
            return "help";
        }
        return "unknown";
    }

    public void learnFromFeedback(String userInput, String correctIntent) {
        mlService.train(userInput, correctIntent);
    }
}