import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SimpleChatbot {

    private final Map<String, String> responses;

    public SimpleChatbot() {
        responses = new HashMap<>();
        initializeResponses();
    }

    private void initializeResponses() {
        responses.put("greeting", "Hello! How can I help you today?");
        responses.put("farewell", "Goodbye! Have a great day!");
        responses.put("gratitude", "You're welcome! Is there anything else I can help with?");
        responses.put("help", "I can answer frequently asked questions. Try asking me about common topics!");
        responses.put("unknown", "I'm sorry, I don't understand that question. Can you please rephrase it or ask about something else?");
    }

    public String getResponse(String userInput) {
        String intent = extractIntent(userInput);
        return responses.getOrDefault(intent, responses.get("unknown"));
    }

    private String extractIntent(String userInput) {
        String lowerInput = userInput.toLowerCase();
        if (lowerInput.contains("hello") || lowerInput.contains("hi")) {
            return "greeting";
        } else if (lowerInput.contains("bye") || lowerInput.contains("goodbye")) {
            return "farewell";
        } else if (lowerInput.contains("thank")) {
            return "gratitude";
        } else if (lowerInput.contains("help")) {
            return "help";
        }
        return "unknown";
    }

    public static void main(String[] args) {
        SimpleChatbot chatbot = new SimpleChatbot();

        System.out.println("AI Chatbot: Hello! I'm your AI assistant. How can I help you today?");
        System.out.println("Type 'exit' to end the conversation.");
        System.out.println();

        // Test some sample interactions
        String[] testInputs = {
            "hello",
            "hi there",
            "how are you",
            "thank you",
            "bye",
            "help me",
            "what is this",
            "exit"
        };

        for (String input : testInputs) {
            if (input.equals("exit")) {
                System.out.println("AI Chatbot: Goodbye! Have a great day!");
                break;
            }

            System.out.println("You: " + input);
            String response = chatbot.getResponse(input);
            System.out.println("AI Chatbot: " + response);
            System.out.println();
        }
    }
}