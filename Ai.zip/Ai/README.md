# AI Chatbot

A Java-based AI chatbot with Natural Language Processing (NLP) capabilities and machine learning integration.

## Features

- **Natural Language Processing**: Uses OpenNLP for sentence detection, tokenization, and part-of-speech tagging
- **Intent Recognition**: Rule-based and machine learning-based intent classification
- **Entity Extraction**: Identifies nouns and entities from user input
- **Machine Learning**: Deep learning model using Deeplearning4j for intent prediction and continuous learning
- **Web Interface**: Real-time chat interface built with HTML, CSS, and JavaScript
- **REST API**: RESTful endpoints for chatbot interactions
- **Spring Boot**: Built on Spring Boot framework for easy deployment

## Architecture

The chatbot consists of several key components:

1. **ChatbotApplication**: Main Spring Boot application class
2. **ChatbotService**: Core service handling user interactions and response generation
3. **NLPProcessor**: Handles natural language processing tasks using OpenNLP
4. **MachineLearningService**: Implements deep learning for intent classification
5. **ChatbotController**: REST API endpoints for chat functionality
6. **WebController**: Serves the web interface

## Prerequisites

- Java 17 or higher
- Maven 3.6+ (for building and running)

## Installation

1. Clone the repository
2. Navigate to the project directory
3. Run `mvn clean install` to build the project
4. Run `mvn spring-boot:run` to start the application

## Usage

1. Open a web browser and navigate to `http://localhost:8080`
2. Start chatting with the AI chatbot
3. The chatbot can handle various intents like greetings, farewells, gratitude, and help requests

## API Endpoints

- `GET /`: Serves the chat interface
- `POST /api/chat/message`: Send a message to the chatbot
- `GET /api/chat/health`: Health check endpoint

## Configuration

The application uses Spring Boot's default configuration. You can customize settings in `application.properties` if needed.

## Training Data

The chatbot comes with pre-configured responses for common intents. The machine learning model can be further trained with user feedback to improve accuracy over time.

## Technologies Used

- **Spring Boot**: Web framework
- **OpenNLP**: Natural language processing
- **Deeplearning4j**: Machine learning framework
- **ND4J**: Scientific computing for Java
- **Thymeleaf**: Template engine for web interface
- **HTML/CSS/JavaScript**: Frontend interface

## Future Enhancements

- Integration with more advanced NLP models
- Support for multiple languages
- Voice input/output capabilities
- Integration with external knowledge bases
- Advanced conversation flow management